<?php
  define('ENDPOINT_V1', 'apriva/v1');
